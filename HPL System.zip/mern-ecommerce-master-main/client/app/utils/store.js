export const sortOptions = [
  { value: 0, label: 'Newest First' },
  { value: 1, label: 'Price High to Low' },
  { value: 2, label: 'Price Low to High' }
];
