module.exports = {
  stateCode: 'CA',
  stateName: 'California',
  stateTaxRate: 0.05
};
