const Mailchimp = require('mailchimp-api-v3');

const keys = require('../config/keys');

const { key, listKey } = keys.mailchimp;

class MailchimpService {
  init() {
    try {
      return new Mailchimp(key);
    } catch (error) {
      console.warn('Missing mailgun keys');
    }
  }
}

const mailchimp = new MailchimpService().init();

exports.subscribeToNewsletter = async email => {
  try {
    return await mailchimp.post(`lists/${listKey}/members`, {
      email_address: email,
      status: 'subscribed'
    });
  } catch (error) {
    return error;
  }
};


/*const nodemailer = require('nodemailer');
const template = require('../config/template');
const keys = require('../config/keys');

const { smtpHost, smtpPort, smtpUser, smtpPass, sender } = keys.smtp;

const transporter = nodemailer.createTransport({
  host: smtpHost,
  port: smtpPort,
  auth: {
    user: smtpUser,
    pass: smtpPass
  }
});

exports.sendNewsletterSubscriptionEmail = async (email) => {
  try {
    const message = template.newsletterSubscriptionEmail();
    const mailOptions = {
      from: `MERN Store! <${sender}>`,
      to: email,
      subject: message.subject,
      html: message.html
    };

    return await transporter.sendMail(mailOptions);
  } catch (error) {
    return error;
  }
};*/