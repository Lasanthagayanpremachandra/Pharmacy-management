const formData = require('form-data');
const Mailgun = require('mailgun.js');
const mailgun = new Mailgun(formData);
const mg = mailgun.client({username: 'api', key: process.env.MAILGUN_API_KEY || 'db188816f1b3e9f65b6aa5303a11e122-ed54d65c-f77caec5'});

mg.messages.create('sandbox7e6b45f6e47e4424a29a534d60ce8e42.mailgun.org', {
	from: "Excited User <test@test.com>",
	to: ["plglasanthag211120@gmail.com"],
	subject: "Hello",
	text: "Testing some Mailgun awesomeness!",
	html: "<h1>Testing some Mailgun awesomeness!</h1>"
})
.then(msg => console.log(msg)) // logs response data
.catch(err => console.log(err)); // logs any error